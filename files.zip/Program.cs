using System;

class Program
{
    static void Main()
    {
        Product[] Store = new Product[]
        {
            new Product(1, "Ballpen (12pcs)",   45.00,  30),
            new Product(2, "Notebook (5pcs)",   120.00, 20),
            new Product(3, "Ruler",             25.00,  15),
            new Product(4, "Highlighter Set",   185.00, 10),
            new Product(5, "Scissors",          75.00,  12),
            new Product(6, "Correction Tape",   55.00,  18),
            new Product(7, "Stapler",           250.00,  8),
            new Product(8, "Folder (10pcs)",    95.00,  14),
            new Product(9, "Calculator",        499.00,  5),
            new Product(10,"Pencil Case",       160.00,  9)
        };

        CartItem[] Cart = new CartItem[10];
        int CartCount = 0;

        string AddMore = "Y";

        while (AddMore == "Y")
        {
            Console.WriteLine("\n========== STORE MENU ==========");
            for (int i = 0; i < Store.Length; i++)
            {
                Store[i].DisplayProduct();
            }
            Console.WriteLine("=================================");

            Console.Write("\nEnter product number: ");
            string ProdInput = Console.ReadLine();

            if (!int.TryParse(ProdInput, out int ProductNumber))
            {
                Console.WriteLine("Invalid input. Please enter a number.");
                continue;
            }

            if (ProductNumber < 1 || ProductNumber > Store.Length)
            {
                Console.WriteLine("Invalid product number. Please choose from the menu.");
                continue;
            }

            Product Selected = Store[ProductNumber - 1];

            if (Selected.RemainingStock == 0)
            {
                Console.WriteLine($"Sorry, {Selected.Name} is out of stock.");
                continue;
            }

            Console.Write("Enter quantity: ");
            string QtyInput = Console.ReadLine();

            if (!int.TryParse(QtyInput, out int Quantity) || Quantity <= 0)
            {
                Console.WriteLine("Invalid quantity. Must be a positive number.");
                continue;
            }

            if (!Selected.HasEnoughStock(Quantity))
            {
                Console.WriteLine($"Not enough stock available. Only {Selected.RemainingStock} left.");
                continue;
            }

            // check if cart is full before adding a new product
            bool AlreadyInCart = false;
            int ExistingIndex = -1;

            for (int i = 0; i < CartCount; i++)
            {
                if (Cart[i].Product.Id == Selected.Id)
                {
                    AlreadyInCart = true;
                    ExistingIndex = i;
                    break;
                }
            }

            if (!AlreadyInCart && CartCount >= 10)
            {
                Console.WriteLine("Cart is full. Cannot add more products.");
                continue;
            }

            if (AlreadyInCart)
            {
                Cart[ExistingIndex].Quantity += Quantity;
                Cart[ExistingIndex].SubTotal += Selected.GetItemTotal(Quantity);
            }
            else
            {
                Cart[CartCount] = new CartItem
                {
                    Product  = Selected,
                    Quantity = Quantity,
                    SubTotal = Selected.GetItemTotal(Quantity)
                };
                CartCount++;
            }

            Selected.DeductStock(Quantity);
            Console.WriteLine($"\n\"{Selected.Name}\" x{Quantity} added to cart!");

            Console.Write("\nAdd another item? (Y/N): ");
            string Answer = Console.ReadLine();

            if (Answer == null)
            {
                AddMore = "N";
            }
            else
            {
                AddMore = Answer.Trim().ToUpper();

                while (AddMore != "Y" && AddMore != "N")
                {
                    Console.Write("Please type Y or N only: ");
                    Answer  = Console.ReadLine();
                    AddMore = Answer == null ? "N" : Answer.Trim().ToUpper();
                }
            }
        }

        // ---- RECEIPT ----
        if (CartCount == 0)
        {
            Console.WriteLine("\nNo items in cart. Thank you!");
            return;
        }

        Console.WriteLine("\n========== RECEIPT ==========");

        double GrandTotal = 0;

        for (int i = 0; i < CartCount; i++)
        {
            Console.WriteLine($"  {Cart[i].Product.Name} x{Cart[i].Quantity} = P{Cart[i].SubTotal:F2}");
            GrandTotal += Cart[i].SubTotal;
        }

        Console.WriteLine("-----------------------------");
        Console.WriteLine($"  Grand Total : P{GrandTotal:F2}");

        double Discount = 0;

        if (GrandTotal >= 5000)
        {
            Discount = GrandTotal * 0.10;
            Console.WriteLine($"  Discount    : -P{Discount:F2} (10%)");
        }

        double FinalTotal = GrandTotal - Discount;
        Console.WriteLine($"  Final Total : P{FinalTotal:F2}");
        Console.WriteLine("==============================");

        // ---- UPDATED STOCK ----
        Console.WriteLine("\n======= UPDATED STOCK =======");
        for (int i = 0; i < Store.Length; i++)
        {
            Store[i].DisplayProduct();
        }
        Console.WriteLine("==============================");

        Console.WriteLine("\nThank you for shopping with us!");
    }
}
